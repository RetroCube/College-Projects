﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.CmdLogout = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.PicBoxLogo = New System.Windows.Forms.PictureBox()
        CType(Me.PicBoxLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 264)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(108, 52)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Calculator"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'CmdLogout
        '
        Me.CmdLogout.Location = New System.Drawing.Point(208, 369)
        Me.CmdLogout.Name = "CmdLogout"
        Me.CmdLogout.Size = New System.Drawing.Size(108, 52)
        Me.CmdLogout.TabIndex = 2
        Me.CmdLogout.Text = "Log Out"
        Me.CmdLogout.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(208, 264)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(108, 52)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "Currency Converter"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(12, 369)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(108, 52)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "Admin And Settings"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'PicBoxLogo
        '
        Me.PicBoxLogo.BackgroundImage = Global.SoftwareDevelopmentAssignmentTwo.My.Resources.Resources.FlyCymru_Logo
        Me.PicBoxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PicBoxLogo.Location = New System.Drawing.Point(7, 12)
        Me.PicBoxLogo.Name = "PicBoxLogo"
        Me.PicBoxLogo.Size = New System.Drawing.Size(322, 225)
        Me.PicBoxLogo.TabIndex = 0
        Me.PicBoxLogo.TabStop = False
        '
        'MainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(338, 445)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.CmdLogout)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PicBoxLogo)
        Me.Name = "MainMenu"
        Me.Text = "Fly Cymru Travel - Main Menu"
        CType(Me.PicBoxLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PicBoxLogo As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents CmdLogout As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
End Class
