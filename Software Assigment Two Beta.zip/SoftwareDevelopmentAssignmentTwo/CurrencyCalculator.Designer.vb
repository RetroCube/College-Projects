﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CurrencyCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.CurrentCurrency = New System.Windows.Forms.ComboBox()
        Me.LBLHave = New System.Windows.Forms.Label()
        Me.TxtCurrent = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ExchangeCurrency = New System.Windows.Forms.ComboBox()
        Me.OutputExchangeFinal = New System.Windows.Forms.TextBox()
        Me.LblExchangeRate = New System.Windows.Forms.Label()
        Me.CmdAdmin = New System.Windows.Forms.Button()
        Me.CmdConvert = New System.Windows.Forms.Button()
        Me.LblExchange = New System.Windows.Forms.Label()
        Me.CmdMenu = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.SoftwareDevelopmentAssignmentTwo.My.Resources.Resources.FlyCymru_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(178, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(176, 149)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'CurrentCurrency
        '
        Me.CurrentCurrency.FormattingEnabled = True
        Me.CurrentCurrency.Location = New System.Drawing.Point(15, 194)
        Me.CurrentCurrency.Name = "CurrentCurrency"
        Me.CurrentCurrency.Size = New System.Drawing.Size(235, 21)
        Me.CurrentCurrency.TabIndex = 1
        '
        'LBLHave
        '
        Me.LBLHave.AutoSize = True
        Me.LBLHave.ForeColor = System.Drawing.SystemColors.Control
        Me.LBLHave.Location = New System.Drawing.Point(12, 178)
        Me.LBLHave.Name = "LBLHave"
        Me.LBLHave.Size = New System.Drawing.Size(84, 13)
        Me.LBLHave.TabIndex = 2
        Me.LBLHave.Text = "Currency I Have"
        '
        'TxtCurrent
        '
        Me.TxtCurrent.Location = New System.Drawing.Point(48, 273)
        Me.TxtCurrent.Name = "TxtCurrent"
        Me.TxtCurrent.Size = New System.Drawing.Size(158, 20)
        Me.TxtCurrent.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(109, 257)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Amount"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.Control
        Me.Label2.Location = New System.Drawing.Point(289, 178)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Currency I Want"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.Control
        Me.Label3.Location = New System.Drawing.Point(371, 257)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(94, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Exhanged Amount"
        '
        'ExchangeCurrency
        '
        Me.ExchangeCurrency.FormattingEnabled = True
        Me.ExchangeCurrency.Location = New System.Drawing.Point(292, 194)
        Me.ExchangeCurrency.Name = "ExchangeCurrency"
        Me.ExchangeCurrency.Size = New System.Drawing.Size(235, 21)
        Me.ExchangeCurrency.TabIndex = 7
        '
        'OutputExchangeFinal
        '
        Me.OutputExchangeFinal.Location = New System.Drawing.Point(334, 273)
        Me.OutputExchangeFinal.Name = "OutputExchangeFinal"
        Me.OutputExchangeFinal.Size = New System.Drawing.Size(158, 20)
        Me.OutputExchangeFinal.TabIndex = 8
        '
        'LblExchangeRate
        '
        Me.LblExchangeRate.AutoSize = True
        Me.LblExchangeRate.ForeColor = System.Drawing.SystemColors.Control
        Me.LblExchangeRate.Location = New System.Drawing.Point(12, 445)
        Me.LblExchangeRate.Name = "LblExchangeRate"
        Me.LblExchangeRate.Size = New System.Drawing.Size(87, 13)
        Me.LblExchangeRate.TabIndex = 9
        Me.LblExchangeRate.Text = "Exchange Rate :"
        '
        'CmdAdmin
        '
        Me.CmdAdmin.Location = New System.Drawing.Point(416, 385)
        Me.CmdAdmin.Name = "CmdAdmin"
        Me.CmdAdmin.Size = New System.Drawing.Size(111, 23)
        Me.CmdAdmin.TabIndex = 10
        Me.CmdAdmin.Text = "Settings"
        Me.CmdAdmin.UseVisualStyleBackColor = True
        '
        'CmdConvert
        '
        Me.CmdConvert.Location = New System.Drawing.Point(416, 356)
        Me.CmdConvert.Name = "CmdConvert"
        Me.CmdConvert.Size = New System.Drawing.Size(111, 23)
        Me.CmdConvert.TabIndex = 11
        Me.CmdConvert.Text = "Convert"
        Me.CmdConvert.UseVisualStyleBackColor = True
        '
        'LblExchange
        '
        Me.LblExchange.AutoSize = True
        Me.LblExchange.Location = New System.Drawing.Point(105, 445)
        Me.LblExchange.Name = "LblExchange"
        Me.LblExchange.Size = New System.Drawing.Size(39, 13)
        Me.LblExchange.TabIndex = 12
        Me.LblExchange.Text = "Label4"
        '
        'CmdMenu
        '
        Me.CmdMenu.Location = New System.Drawing.Point(416, 414)
        Me.CmdMenu.Name = "CmdMenu"
        Me.CmdMenu.Size = New System.Drawing.Size(111, 23)
        Me.CmdMenu.TabIndex = 13
        Me.CmdMenu.Text = "Menu"
        Me.CmdMenu.UseVisualStyleBackColor = True
        '
        'CurrencyCalculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(549, 485)
        Me.Controls.Add(Me.CmdMenu)
        Me.Controls.Add(Me.LblExchange)
        Me.Controls.Add(Me.CmdConvert)
        Me.Controls.Add(Me.CmdAdmin)
        Me.Controls.Add(Me.LblExchangeRate)
        Me.Controls.Add(Me.OutputExchangeFinal)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtCurrent)
        Me.Controls.Add(Me.LBLHave)
        Me.Controls.Add(Me.CurrentCurrency)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.ExchangeCurrency)
        Me.Name = "CurrencyCalculator"
        Me.Text = "CurrencyCalculator"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents CurrentCurrency As ComboBox
    Friend WithEvents LBLHave As Label
    Friend WithEvents TxtCurrent As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents ExchangeCurrency As ComboBox
    Friend WithEvents OutputExchangeFinal As TextBox
    Friend WithEvents LblExchangeRate As Label
    Friend WithEvents CmdAdmin As Button
    Friend WithEvents CmdConvert As Button
    Friend WithEvents LblExchange As Label
    Friend WithEvents CmdMenu As Button
End Class
