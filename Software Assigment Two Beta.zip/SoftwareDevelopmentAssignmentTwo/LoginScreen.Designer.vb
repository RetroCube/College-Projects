﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LoginScreen
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LoginScreen))
        Me.CmdEnd = New System.Windows.Forms.Button()
        Me.LblUsername = New System.Windows.Forms.Label()
        Me.LblPassword = New System.Windows.Forms.Label()
        Me.TxtUsername = New System.Windows.Forms.TextBox()
        Me.TxtPassword = New System.Windows.Forms.TextBox()
        Me.ImageLogo = New System.Windows.Forms.PictureBox()
        Me.Cmdlogin = New System.Windows.Forms.Button()
        Me.REMOVE = New System.Windows.Forms.Button()
        CType(Me.ImageLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CmdEnd
        '
        Me.CmdEnd.Location = New System.Drawing.Point(373, 178)
        Me.CmdEnd.Name = "CmdEnd"
        Me.CmdEnd.Size = New System.Drawing.Size(130, 23)
        Me.CmdEnd.TabIndex = 0
        Me.CmdEnd.Text = "Close Program"
        Me.CmdEnd.UseVisualStyleBackColor = True
        '
        'LblUsername
        '
        Me.LblUsername.AutoSize = True
        Me.LblUsername.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.LblUsername.Location = New System.Drawing.Point(224, 53)
        Me.LblUsername.Name = "LblUsername"
        Me.LblUsername.Size = New System.Drawing.Size(55, 13)
        Me.LblUsername.TabIndex = 1
        Me.LblUsername.Text = "Username"
        '
        'LblPassword
        '
        Me.LblPassword.AutoSize = True
        Me.LblPassword.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.LblPassword.Location = New System.Drawing.Point(224, 84)
        Me.LblPassword.Name = "LblPassword"
        Me.LblPassword.Size = New System.Drawing.Size(53, 13)
        Me.LblPassword.TabIndex = 2
        Me.LblPassword.Text = "Password"
        '
        'TxtUsername
        '
        Me.TxtUsername.Location = New System.Drawing.Point(285, 50)
        Me.TxtUsername.Name = "TxtUsername"
        Me.TxtUsername.Size = New System.Drawing.Size(175, 20)
        Me.TxtUsername.TabIndex = 3
        '
        'TxtPassword
        '
        Me.TxtPassword.Location = New System.Drawing.Point(285, 81)
        Me.TxtPassword.Name = "TxtPassword"
        Me.TxtPassword.Size = New System.Drawing.Size(175, 20)
        Me.TxtPassword.TabIndex = 4
        '
        'ImageLogo
        '
        Me.ImageLogo.Image = CType(resources.GetObject("ImageLogo.Image"), System.Drawing.Image)
        Me.ImageLogo.InitialImage = CType(resources.GetObject("ImageLogo.InitialImage"), System.Drawing.Image)
        Me.ImageLogo.Location = New System.Drawing.Point(12, 12)
        Me.ImageLogo.Name = "ImageLogo"
        Me.ImageLogo.Size = New System.Drawing.Size(187, 174)
        Me.ImageLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ImageLogo.TabIndex = 5
        Me.ImageLogo.TabStop = False
        '
        'Cmdlogin
        '
        Me.Cmdlogin.Location = New System.Drawing.Point(227, 178)
        Me.Cmdlogin.Name = "Cmdlogin"
        Me.Cmdlogin.Size = New System.Drawing.Size(130, 23)
        Me.Cmdlogin.TabIndex = 6
        Me.Cmdlogin.Text = "Login"
        Me.Cmdlogin.UseVisualStyleBackColor = True
        '
        'REMOVE
        '
        Me.REMOVE.Location = New System.Drawing.Point(329, 125)
        Me.REMOVE.Name = "REMOVE"
        Me.REMOVE.Size = New System.Drawing.Size(75, 23)
        Me.REMOVE.TabIndex = 7
        Me.REMOVE.Text = "SKIP"
        Me.REMOVE.UseVisualStyleBackColor = True
        '
        'LoginScreen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(515, 213)
        Me.Controls.Add(Me.REMOVE)
        Me.Controls.Add(Me.Cmdlogin)
        Me.Controls.Add(Me.ImageLogo)
        Me.Controls.Add(Me.TxtPassword)
        Me.Controls.Add(Me.TxtUsername)
        Me.Controls.Add(Me.LblPassword)
        Me.Controls.Add(Me.LblUsername)
        Me.Controls.Add(Me.CmdEnd)
        Me.Name = "LoginScreen"
        Me.Text = "Fly Cymru Travel - Login "
        CType(Me.ImageLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents CmdEnd As Button
    Friend WithEvents LblUsername As Label
    Friend WithEvents LblPassword As Label
    Friend WithEvents TxtUsername As TextBox
    Friend WithEvents TxtPassword As TextBox
    Friend WithEvents ImageLogo As PictureBox
    Friend WithEvents Cmdlogin As Button
    Friend WithEvents REMOVE As Button
End Class
