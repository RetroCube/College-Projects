﻿Public Class CurrencyCalculator


    Private Sub CurrencyCalculator_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Setting all of the items inside the drop Down boxes
        CurrentCurrency.Items.Add("Great British Pound  (£GBP)")
        CurrentCurrency.Items.Add("United States Dollar ($USD)")
        CurrentCurrency.Items.Add("European Euro        (€EUR)")
        CurrentCurrency.Items.Add("Japanese Yen         (¥JPY)")
        CurrentCurrency.Items.Add("Canadian Dollar      ($CAD)")


        ExchangeCurrency.Items.Add("Great British Pound  (£GBP)")
        ExchangeCurrency.Items.Add("United States Dollar ($USD)")
        ExchangeCurrency.Items.Add("European Euro        (€EUR)")
        ExchangeCurrency.Items.Add("Japanese Yen         (¥JPY)")
        ExchangeCurrency.Items.Add("Canadian Dollar      ($CAD)")


    End Sub
    'Ensures that you are putting currency/ numbers into boxs
    Private Sub TextBox2_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles OutputExchangeFinal.KeyPress
        If e.KeyChar > "31" And (e.KeyChar < "0" Or e.KeyChar > "9") Then ' Only allows numerical keys and a .
            e.Handled = True
        End If
        If e.KeyChar = Convert.ToChar(Keys.Space) Then ' Disable spacebar <img src='http://powerbot-gold4rs.netdna-ssl.com/community//public/style_emoticons/<#EMO_DIR#>/thinking.png' class='bbc_emoticon' alt=':/' /> no need for it
            e.KeyChar = Convert.ToChar(Keys.None)
        End If
    End Sub

    'CURRECNY CONVERTER
    Private Sub CmdConvert_Click(sender As Object, e As EventArgs) Handles CmdConvert.Click
        ' Ensures you have something typed in
        If TxtCurrent.Text.Equals(Nothing) Then
            MsgBox("Please enter a number to convert")
        End If

        'Checks to see that you have not got two of the same currencys
        If CurrentCurrency.SelectedItem = ExchangeCurrency.SelectedItem Then
            MsgBox("No point in trying to convert the same currency.")
        End If

        'Actual Exchange Calculations Below



        '<---Great British  Pound --->

        'GBP TO USD
        If CurrentCurrency.SelectedItem.Equals("Great British Pound  (£GBP)") And ExchangeCurrency.SelectedItem.Equals("United States Dollar ($USD)") Then
            Dim GBPtoUSD As Decimal = TxtCurrent.Text * 1.44
            OutputExchangeFinal.Text = GBPtoUSD.ToString
        End If


        'GBP TO EUR
        If CurrentCurrency.SelectedItem.Equals("Great British Pound  (£GBP)") And ExchangeCurrency.SelectedItem.Equals("European Euro        (€EUR)") Then
            Dim GBPtoEUR As Decimal = TxtCurrent.Text * 1.27
            OutputExchangeFinal.Text = GBPtoEUR.ToString
        End If


        'GBP TO JPY
        If CurrentCurrency.SelectedItem.Equals("Great British Pound  (£GBP)") And ExchangeCurrency.SelectedItem.Equals("Japanese Yen         (¥JPY)") Then
            Dim GBPtoJPY As Decimal = TxtCurrent.Text * 154.56
            OutputExchangeFinal.Text = GBPtoJPY.ToString
        End If


        'GBP TO CAD
        If CurrentCurrency.SelectedItem.Equals("Great British Pound  (£GBP)") And ExchangeCurrency.SelectedItem.Equals("Canadian Dollar      ($CAD)") Then
            Dim GBPtoCAD As Decimal = TxtCurrent.Text * 4.86
            OutputExchangeFinal.Text = GBPtoCAD.ToString
        End If

        '<-----United States Dollar ----->

        'USD to GBP
        If CurrentCurrency.SelectedItem.Equals("United States Dollar ($USD)") And ExchangeCurrency.SelectedItem.Equals("Great British Pound  (£GBP)") Then
            Dim USDtoGBP As Decimal = TxtCurrent.Text * 0.69
            OutputExchangeFinal.Text = USDtoGBP.ToString
        End If

        'USD to EUR
        If CurrentCurrency.SelectedItem.Equals("United States Dollar ($USD)") And ExchangeCurrency.SelectedItem.Equals("European Euro        (€EUR)") Then
            Dim USDtoEUR As Decimal = TxtCurrent.Text * 0.88
            OutputExchangeFinal.Text = USDtoEUR.ToString
        End If

        'USD to JPY
        If CurrentCurrency.SelectedItem.Equals("United States Dollar ($USD)") And ExchangeCurrency.SelectedItem.Equals("Japanese Yen         (¥JPY)") Then
            Dim USDtoJPY As Decimal = TxtCurrent.Text * 107.11
            OutputExchangeFinal.Text = USDtoJPY.ToString
        End If

        'USD to CAD
        If CurrentCurrency.SelectedItem.Equals("United States Dollar ($USD)") And ExchangeCurrency.SelectedItem.Equals("Canadian Dollar      ($CAD)") Then
            Dim USDtoCAD As Decimal = TxtCurrent.Text * 1.29
            OutputExchangeFinal.Text = USDtoCAD.ToString
        End If

        '<-----Europian Euro----->

        ' EURO to GBP
        If CurrentCurrency.SelectedItem.Equals("European Euro        (€EUR)") And ExchangeCurrency.SelectedItem.Equals("Great British Pound  (£GBP)") Then
            Dim EURtoGBP As Decimal = TxtCurrent.Text * 0.79
            OutputExchangeFinal.Text = EURtoGBP.ToString
        End If

        ' EURO to USD
        If CurrentCurrency.SelectedItem.Equals("European Euro        (€EUR)") And ExchangeCurrency.SelectedItem.Equals("United States Dollar ($USD)") Then
            Dim EURtoUSD As Decimal = TxtCurrent.Text * 1.14
            OutputExchangeFinal.Text = EURtoUSD.ToString
        End If

        ' EURO to JPY
        If CurrentCurrency.SelectedItem.Equals("European Euro        (€EUR)") And ExchangeCurrency.SelectedItem.Equals("Japanese Yen         (¥JPY)") Then
            Dim EURtoUSD As Decimal = TxtCurrent.Text * 122.15
            OutputExchangeFinal.Text = EURtoUSD.ToString
        End If

        ' EURO to CAD
        If CurrentCurrency.SelectedItem.Equals("European Euro        (€EUR)") And ExchangeCurrency.SelectedItem.Equals("Canadian Dollar      ($CAD)") Then
            Dim EURtoCAD As Decimal = TxtCurrent.Text * 1.47
            OutputExchangeFinal.Text = EURtoCAD.ToString
        End If

        '<-----Japanise Yeun----->


        ' JPY to GBP
        If CurrentCurrency.SelectedItem.Equals("Japanese Yen         (¥JPY)") And ExchangeCurrency.SelectedItem.Equals("Great British Pound  (£GBP)") Then
            Dim JPYtoGBP As Decimal = TxtCurrent.Text * 0.0065
            OutputExchangeFinal.Text = JPYtoGBP.ToString
        End If

        ' JPY to USD
        If CurrentCurrency.SelectedItem.Equals("Japanese Yen         (¥JPY)") And ExchangeCurrency.SelectedItem.Equals("United States Dollar ($USD)") Then
            Dim JPYtoUSD As Decimal = TxtCurrent.Text * 0.0093
            OutputExchangeFinal.Text = JPYtoUSD.ToString
        End If

        ' JPY to EUR
        If CurrentCurrency.SelectedItem.Equals("Japanese Yen         (¥JPY)") And ExchangeCurrency.SelectedItem.Equals("European Euro        (€EUR)") Then
            Dim JPYtoEUR As Decimal = TxtCurrent.Text * 0.0082
            OutputExchangeFinal.Text = JPYtoEUR.ToString
        End If

        ' JPY to CAD
        If CurrentCurrency.SelectedItem.Equals("Japanese Yen         (¥JPY)") And ExchangeCurrency.SelectedItem.Equals("Canadian Dollar      ($CAD)") Then
            Dim JPYtoCAD As Decimal = TxtCurrent.Text * 0.012
            OutputExchangeFinal.Text = JPYtoCAD.ToString
        End If


        '<-----Canadin Dollar----->



        ' CAD to GBP
        If CurrentCurrency.SelectedItem.Equals("Canadian Dollar      ($CAD)") And ExchangeCurrency.SelectedItem.Equals("Great British Pound  (£GBP)") Then
            Dim CADtoGBP As Decimal = TxtCurrent.Text * 0.54
            OutputExchangeFinal.Text = CADtoGBP.ToString
        End If

        ' CAD to USD
        If CurrentCurrency.SelectedItem.Equals("Canadian Dollar      ($CAD)") And ExchangeCurrency.SelectedItem.Equals("United States Dollar ($USD)") Then
            Dim CADtoUSD As Decimal = TxtCurrent.Text * 0.77
            OutputExchangeFinal.Text = CADtoUSD.ToString
        End If

        ' CAD to EUR
        If CurrentCurrency.SelectedItem.Equals("Canadian Dollar      ($CAD)") And ExchangeCurrency.SelectedItem.Equals("European Euro        (€EUR)") Then
            Dim CADtoEUR As Decimal = TxtCurrent.Text * 0.68
            OutputExchangeFinal.Text = CADtoEUR.ToString
        End If

        ' CAD to JPY
        If CurrentCurrency.SelectedItem.Equals("Canadian Dollar      ($CAD)") And ExchangeCurrency.SelectedItem.Equals("Japanese Yen         (¥JPY)") Then
            Dim CADtoJPY As Decimal = TxtCurrent.Text * 82.97
            OutputExchangeFinal.Text = CADtoJPY.ToString
        End If
    End Sub
    ' Back To Menu
    Private Sub CmdAdmin_Click(sender As Object, e As EventArgs) Handles CmdAdmin.Click
        MsgBox("Sorry This feature is Currently Unavalible Please Update the software or see network Adminastrator")
        
    End Sub

    Private Sub CmdMenu_Click_1(sender As Object, e As EventArgs) Handles CmdMenu.Click
        Me.Hide()
        MainMenu.Show()
    End Sub
End Class