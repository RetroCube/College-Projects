﻿Public Class MainMenu
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        MsgBox("Sorry this is not avalible on ths version. Contact me or update this software.")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MsgBox("Please Be Aware this MAy Not Work Please Report Any Bugs")
        Me.Hide()
        Calculator.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MsgBox("Please Be Aware this MAy Not Work Please Report Any Bugs")
        Me.Hide()
        CurrencyCalculator.Show()

    End Sub

    Private Sub CmdLogout_Click(sender As Object, e As EventArgs) Handles CmdLogout.Click
        ' Closes the Program
        Me.Hide()
        LoginScreen.Show()

    End Sub
End Class