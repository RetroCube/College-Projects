﻿Public Class LoginScreen
    'here I have some Declirations and they will be referenced/ used later 
    Dim UserNameAvailable As Integer = 0
    Dim TotalNumberOfUsers As Integer = 3
    Dim UsernamePasswordCheck As Boolean
    Dim UsernameList(2) As String
    Dim PasswordList(2) As String
    Dim InputUsername As String
    Dim InputPassword As String
    Dim t As Integer

    Private Sub LoginScreen_load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'here I Begin to create the array of username and passwords. This is for 3 users and may be editable later in the future
        UsernamePasswordCheck = False
        UsernameList(0) = "Admin"
        PasswordList(0) = "Admin"
        UsernameList(1) = "Bob"
        PasswordList(1) = "sideshow"
        UsernameList(2) = "John"
        PasswordList(2) = "P3oP1E"
        'this shows what needs to be inside the text box when they are Cleared
        TxtPassword.Text = ""
        TxtUsername.Text = ""

        'This below sets the main focus of the username and password to the username
        Me.ActiveControl = Me.TxtUsername

    End Sub


    Private Sub CmdLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmdlogin.Click

        'This places the local variable "Inputusername" and assigns it to the same content as the textbox "username"
        InputUsername = TxtUsername.Text
        'This places the local variable "Inputpassword" and assigns it to the same content as the textbox "password"
        InputPassword = TxtPassword.Text


        'Here i set a username and password check to false before the test
        UsernamePasswordCheck = False



        'This is a Personal Loop that looks at both "Usernames" and "Passwords" in the array
        For Me.t = 0 To 2

            'this checks to see if the usernames and passwords in the array are the same as the ones enteres
            If InputUsername = UsernameList(t) And InputPassword = PasswordList(t) Then
                'If the correct username is found then the if statment is continued if not it ends and the program moves on


                'Here i have now set the check for username and password to true and have it show if it is correct or not
                UsernamePasswordCheck = True



                'Here this code closes the current form and opens the Main Menu
                Me.Hide()
                MainMenu.Show()
                Exit For
                'We then end the Username and Password and the Loop in this statment
            End If



            'Here if the username or password was wrong then the program begins this if staement
        Next Me.t
        If UsernamePasswordCheck = False Then

            'Opens a Message box to bring the problem to the attention of the user
            MsgBox("Wrong Username or Password, please re-enter!")
            Me.ActiveControl = Me.TxtUsername


            'Finaly clears the text boxs for the user to re-enter
            TxtUsername.Text = ""
            TxtPassword.Text = ""

            'We then end the Username and Password and the Loop in this statment
        End If


    End Sub
    Private Sub CmdEnd_Click(sender As Object, e As EventArgs) Handles CmdEnd.Click
        'This ends the program when the button is pressed
        End
    End Sub

    Private Sub REMOVE_Click(sender As Object, e As EventArgs) Handles REMOVE.Click
        Me.Hide()
        CurrencyCalculator.Show()

    End Sub
End Class