﻿Public Class SplashScreen
    Private Sub SplashScreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Starts the timer once program is started
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        'sets the amount that the bar goes up 
        PBarOne.Increment(10)

        ' checks with and IF statment to see if  the above clock has reached 50
        'If it has then closes this and opens login form
        If PBarOne.Value = 100 Then
            LoginScreen.Show()
            Me.Hide()


            'Ends the timer 
            Timer1.Stop()
        End If


    End Sub


End Class
