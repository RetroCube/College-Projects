﻿Public Class Calculator
    Private Sub cmd_Reset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_Reset.Click
        'this code is quite self explanitory, clears all of the tect in the text boxes and lables.
        TxtBxCalc.Clear()
        lbl1.Text = ""
        Lbl2.Text = ""
        Lbl3.Text = ""
        Label1.Text = ""
    End Sub

    Private Sub Cmd0_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_0.Click
        'This code adds the number 0 to the textbox without overwriting the text before. This code also applies to the numbers 1-9
        TxtBxCalc.AppendText(0)
    End Sub

    Private Sub Cmd1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_1.Click
        'This code adds the number 1 to the textbox without overwriting the text before.
        TxtBxCalc.AppendText(1)
    End Sub

    Private Sub Cmd2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_2.Click
        'This code adds the number 2 to the textbox without overwriting the text before.
        TxtBxCalc.AppendText(2)
    End Sub

    Private Sub Cmd3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_3.Click
        'This code adds the number 3 to the textbox without overwriting the text before.
        TxtBxCalc.AppendText(3)
    End Sub

    Private Sub Cmd4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_4.Click
        'This code adds the number 4 to the textbox without overwriting the text before.
        TxtBxCalc.AppendText(4)
    End Sub

    Private Sub Cmd5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_5.Click
        'This code adds the number 5 to the textbox without overwriting the text before.
        TxtBxCalc.AppendText(5)
    End Sub

    Private Sub Cmd6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_6.Click
        'This code adds the number 6 to the textbox without overwriting the text before.e
        TxtBxCalc.AppendText(6)
    End Sub

    Private Sub Cmd7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_7.Click
        'This code adds the number 7 to the textbox without overwriting the text before.
        TxtBxCalc.AppendText(7)
    End Sub

    Private Sub Cmd8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_8.Click
        'This code adds the number 8 to the textbox without overwriting the text before.
        TxtBxCalc.AppendText(8)
    End Sub

    Private Sub CMD9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_9.Click
        'This code adds the number 9 to the textbox without overwriting the text before.
        TxtBxCalc.AppendText(9)
    End Sub

    Private Sub CmdDecimal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_Decimal.Click
        'This code adds the decimal point to the textbox without overwriting the text before.
        TxtBxCalc.AppendText(".")
    End Sub

    Private Sub Cmd_Plus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_Add.Click
        'when this is clicked, the text in the textbox is displayed on the lable for reference, the symbol changes to add and textbox clears.
        lbl1.Text = TxtBxCalc.Text
        Lbl2.Text = "+"
        TxtBxCalc.Clear()

    End Sub

    Private Sub Cmd_Subtract_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_Subtract.Click
        'the same for this line of code as the one above but instead of an add symbol it is a subtract symbol
        lbl1.Text = TxtBxCalc.Text
        Lbl2.Text = "-"
        TxtBxCalc.Clear()
    End Sub

    Private Sub Cmd_Multiply_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_Multiply.Click
        'the same for this line of code as Cmd_Plus_Click above but instead of an add symbol it is a mutiply symbol. I chose not to use the Conventional * symbol as I know that the children that are going to be using it do not neceserraly know what the * symbol means.
        lbl1.Text = TxtBxCalc.Text
        Lbl2.Text = "x"
        TxtBxCalc.Clear()
    End Sub

    Private Sub Cmd_Divide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_Divide.Click
        'the same for this line of code as Cmd_Plus_Click above but instead of an add symbol it is a divide symbol. I chose not to use the Conventional / symbol as I know that the children that are going to be using it do not neceserraly know what the / symbol means.
        lbl1.Text = TxtBxCalc.Text
        Lbl2.Text = "÷"
        TxtBxCalc.Clear()
    End Sub

    Private Sub Cmd_Equ_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_Equ.Click
        Label1.Text = "="
        'this is the overall set up for getting the final answer onto the textbox.
        Lbl3.Text = TxtBxCalc.Text
        'using the char code for this data type allows me to hold a single caracher so I do not need the oberhead of a string.
        Dim sign As Char
        sign = Lbl2.Text
        'setting the variable as double allows the number to be the largest and smallest possible magnitudes.
        Dim n1 As Double
        n1 = Convert.ToDouble(lbl1.Text)
        'see above 
        Dim n2 As Double
        n2 = Convert.ToDouble(Lbl3.Text)
        Dim n3 As Double
        'This makes the program check what button was pressed then shows the answer accordingly 
        Select Case (sign)
            Case "+"
                n3 = n1 + n2
            Case "-"
                n3 = n1 - n2
            Case "x"
                n3 = n1 * n2
            Case "÷"
                n3 = n1 / n2
        End Select
        'this finally tells the program to change to what ever anwser comes out of the 3rd lable.
        TxtBxCalc.Text = Convert.ToString(n3)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_Backspace.Click
        If TxtBxCalc.Text.Length > 0 Then
            TxtBxCalc.Text = TxtBxCalc.Text.Remove(TxtBxCalc.Text.Length - 1, 1)
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmd_menu.Click
        'if this button is pressed it causes this part of the program to close and the main menu to come back up.
        MainMenu.Show()
        Me.Hide()
    End Sub

End Class
