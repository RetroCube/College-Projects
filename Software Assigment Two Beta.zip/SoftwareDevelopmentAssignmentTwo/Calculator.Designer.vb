﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Calculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Cmd_Decimal = New System.Windows.Forms.Button()
        Me.Cmd_0 = New System.Windows.Forms.Button()
        Me.Lbl3 = New System.Windows.Forms.Label()
        Me.Lbl2 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.Cmd_menu = New System.Windows.Forms.Button()
        Me.Cmd_Reset = New System.Windows.Forms.Button()
        Me.Cmd_Backspace = New System.Windows.Forms.Button()
        Me.Cmd_Divide = New System.Windows.Forms.Button()
        Me.TxtBxCalc = New System.Windows.Forms.TextBox()
        Me.Cmd_Subtract = New System.Windows.Forms.Button()
        Me.Cmd_Add = New System.Windows.Forms.Button()
        Me.Cmd_Multiply = New System.Windows.Forms.Button()
        Me.Cmd_Equ = New System.Windows.Forms.Button()
        Me.Cmd_6 = New System.Windows.Forms.Button()
        Me.Cmd_8 = New System.Windows.Forms.Button()
        Me.Cmd_7 = New System.Windows.Forms.Button()
        Me.Cmd_3 = New System.Windows.Forms.Button()
        Me.Cmd_5 = New System.Windows.Forms.Button()
        Me.Cmd_4 = New System.Windows.Forms.Button()
        Me.Cmd_9 = New System.Windows.Forms.Button()
        Me.Cmd_2 = New System.Windows.Forms.Button()
        Me.Cmd_1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Comic Sans MS", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(152, 85)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 38)
        Me.Label1.TabIndex = 68
        '
        'Cmd_Decimal
        '
        Me.Cmd_Decimal.Font = New System.Drawing.Font("Comic Sans MS", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_Decimal.Location = New System.Drawing.Point(153, 208)
        Me.Cmd_Decimal.Name = "Cmd_Decimal"
        Me.Cmd_Decimal.Size = New System.Drawing.Size(41, 37)
        Me.Cmd_Decimal.TabIndex = 67
        Me.Cmd_Decimal.Text = "."
        Me.Cmd_Decimal.UseVisualStyleBackColor = True
        '
        'Cmd_0
        '
        Me.Cmd_0.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_0.Location = New System.Drawing.Point(72, 432)
        Me.Cmd_0.Name = "Cmd_0"
        Me.Cmd_0.Size = New System.Drawing.Size(54, 50)
        Me.Cmd_0.TabIndex = 66
        Me.Cmd_0.Text = "0"
        Me.Cmd_0.UseVisualStyleBackColor = True
        '
        'Lbl3
        '
        Me.Lbl3.AutoSize = True
        Me.Lbl3.BackColor = System.Drawing.Color.Transparent
        Me.Lbl3.Font = New System.Drawing.Font("Comic Sans MS", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl3.Location = New System.Drawing.Point(263, 47)
        Me.Lbl3.Name = "Lbl3"
        Me.Lbl3.Size = New System.Drawing.Size(0, 38)
        Me.Lbl3.TabIndex = 65
        '
        'Lbl2
        '
        Me.Lbl2.AutoSize = True
        Me.Lbl2.BackColor = System.Drawing.Color.Transparent
        Me.Lbl2.Font = New System.Drawing.Font("Comic Sans MS", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl2.Location = New System.Drawing.Point(152, 47)
        Me.Lbl2.Name = "Lbl2"
        Me.Lbl2.Size = New System.Drawing.Size(0, 38)
        Me.Lbl2.TabIndex = 64
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.BackColor = System.Drawing.Color.Transparent
        Me.lbl1.Font = New System.Drawing.Font("Comic Sans MS", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1.Location = New System.Drawing.Point(44, 47)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(0, 38)
        Me.lbl1.TabIndex = 63
        '
        'Cmd_menu
        '
        Me.Cmd_menu.Font = New System.Drawing.Font("Comic Sans MS", 12.0!)
        Me.Cmd_menu.Location = New System.Drawing.Point(270, 376)
        Me.Cmd_menu.Name = "Cmd_menu"
        Me.Cmd_menu.Size = New System.Drawing.Size(60, 104)
        Me.Cmd_menu.TabIndex = 62
        Me.Cmd_menu.Text = "Menu"
        Me.Cmd_menu.UseVisualStyleBackColor = True
        '
        'Cmd_Reset
        '
        Me.Cmd_Reset.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_Reset.Location = New System.Drawing.Point(270, 264)
        Me.Cmd_Reset.Name = "Cmd_Reset"
        Me.Cmd_Reset.Size = New System.Drawing.Size(60, 106)
        Me.Cmd_Reset.TabIndex = 61
        Me.Cmd_Reset.Text = "Reset"
        Me.Cmd_Reset.UseVisualStyleBackColor = True
        '
        'Cmd_Backspace
        '
        Me.Cmd_Backspace.Font = New System.Drawing.Font("Comic Sans MS", 9.0!)
        Me.Cmd_Backspace.Location = New System.Drawing.Point(211, 208)
        Me.Cmd_Backspace.Name = "Cmd_Backspace"
        Me.Cmd_Backspace.Size = New System.Drawing.Size(92, 37)
        Me.Cmd_Backspace.TabIndex = 60
        Me.Cmd_Backspace.Text = "Delete"
        Me.Cmd_Backspace.UseVisualStyleBackColor = True
        '
        'Cmd_Divide
        '
        Me.Cmd_Divide.Font = New System.Drawing.Font("Comic Sans MS", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_Divide.Location = New System.Drawing.Point(106, 208)
        Me.Cmd_Divide.Name = "Cmd_Divide"
        Me.Cmd_Divide.Size = New System.Drawing.Size(41, 37)
        Me.Cmd_Divide.TabIndex = 59
        Me.Cmd_Divide.Text = "÷"
        Me.Cmd_Divide.UseVisualStyleBackColor = True
        '
        'TxtBxCalc
        '
        Me.TxtBxCalc.Font = New System.Drawing.Font("Comic Sans MS", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtBxCalc.Location = New System.Drawing.Point(9, 132)
        Me.TxtBxCalc.Name = "TxtBxCalc"
        Me.TxtBxCalc.Size = New System.Drawing.Size(321, 45)
        Me.TxtBxCalc.TabIndex = 58
        '
        'Cmd_Subtract
        '
        Me.Cmd_Subtract.Font = New System.Drawing.Font("Comic Sans MS", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_Subtract.Location = New System.Drawing.Point(59, 208)
        Me.Cmd_Subtract.Name = "Cmd_Subtract"
        Me.Cmd_Subtract.Size = New System.Drawing.Size(41, 37)
        Me.Cmd_Subtract.TabIndex = 57
        Me.Cmd_Subtract.Text = "-"
        Me.Cmd_Subtract.UseVisualStyleBackColor = True
        '
        'Cmd_Add
        '
        Me.Cmd_Add.Font = New System.Drawing.Font("Comic Sans MS", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_Add.Location = New System.Drawing.Point(209, 264)
        Me.Cmd_Add.Name = "Cmd_Add"
        Me.Cmd_Add.Size = New System.Drawing.Size(54, 106)
        Me.Cmd_Add.TabIndex = 56
        Me.Cmd_Add.Text = "+"
        Me.Cmd_Add.UseVisualStyleBackColor = True
        '
        'Cmd_Multiply
        '
        Me.Cmd_Multiply.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_Multiply.Location = New System.Drawing.Point(12, 208)
        Me.Cmd_Multiply.Name = "Cmd_Multiply"
        Me.Cmd_Multiply.Size = New System.Drawing.Size(41, 37)
        Me.Cmd_Multiply.TabIndex = 55
        Me.Cmd_Multiply.Text = "X"
        Me.Cmd_Multiply.UseVisualStyleBackColor = True
        '
        'Cmd_Equ
        '
        Me.Cmd_Equ.Font = New System.Drawing.Font("Comic Sans MS", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_Equ.Location = New System.Drawing.Point(209, 374)
        Me.Cmd_Equ.Name = "Cmd_Equ"
        Me.Cmd_Equ.Size = New System.Drawing.Size(54, 106)
        Me.Cmd_Equ.TabIndex = 54
        Me.Cmd_Equ.Text = "="
        Me.Cmd_Equ.UseVisualStyleBackColor = True
        '
        'Cmd_6
        '
        Me.Cmd_6.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_6.Location = New System.Drawing.Point(132, 320)
        Me.Cmd_6.Name = "Cmd_6"
        Me.Cmd_6.Size = New System.Drawing.Size(54, 50)
        Me.Cmd_6.TabIndex = 53
        Me.Cmd_6.Text = "6"
        Me.Cmd_6.UseVisualStyleBackColor = True
        '
        'Cmd_8
        '
        Me.Cmd_8.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_8.Location = New System.Drawing.Point(72, 376)
        Me.Cmd_8.Name = "Cmd_8"
        Me.Cmd_8.Size = New System.Drawing.Size(54, 50)
        Me.Cmd_8.TabIndex = 52
        Me.Cmd_8.Text = "8"
        Me.Cmd_8.UseVisualStyleBackColor = True
        '
        'Cmd_7
        '
        Me.Cmd_7.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_7.Location = New System.Drawing.Point(12, 376)
        Me.Cmd_7.Name = "Cmd_7"
        Me.Cmd_7.Size = New System.Drawing.Size(54, 50)
        Me.Cmd_7.TabIndex = 51
        Me.Cmd_7.Text = "7"
        Me.Cmd_7.UseVisualStyleBackColor = True
        '
        'Cmd_3
        '
        Me.Cmd_3.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_3.Location = New System.Drawing.Point(132, 264)
        Me.Cmd_3.Name = "Cmd_3"
        Me.Cmd_3.Size = New System.Drawing.Size(54, 50)
        Me.Cmd_3.TabIndex = 50
        Me.Cmd_3.Text = "3"
        Me.Cmd_3.UseVisualStyleBackColor = True
        '
        'Cmd_5
        '
        Me.Cmd_5.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_5.Location = New System.Drawing.Point(72, 320)
        Me.Cmd_5.Name = "Cmd_5"
        Me.Cmd_5.Size = New System.Drawing.Size(54, 50)
        Me.Cmd_5.TabIndex = 49
        Me.Cmd_5.Text = "5"
        Me.Cmd_5.UseVisualStyleBackColor = True
        '
        'Cmd_4
        '
        Me.Cmd_4.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_4.Location = New System.Drawing.Point(12, 320)
        Me.Cmd_4.Name = "Cmd_4"
        Me.Cmd_4.Size = New System.Drawing.Size(54, 50)
        Me.Cmd_4.TabIndex = 48
        Me.Cmd_4.Text = "4"
        Me.Cmd_4.UseVisualStyleBackColor = True
        '
        'Cmd_9
        '
        Me.Cmd_9.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_9.Location = New System.Drawing.Point(132, 376)
        Me.Cmd_9.Name = "Cmd_9"
        Me.Cmd_9.Size = New System.Drawing.Size(54, 50)
        Me.Cmd_9.TabIndex = 47
        Me.Cmd_9.Text = "9"
        Me.Cmd_9.UseVisualStyleBackColor = True
        '
        'Cmd_2
        '
        Me.Cmd_2.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_2.Location = New System.Drawing.Point(72, 264)
        Me.Cmd_2.Name = "Cmd_2"
        Me.Cmd_2.Size = New System.Drawing.Size(54, 50)
        Me.Cmd_2.TabIndex = 46
        Me.Cmd_2.Text = "2"
        Me.Cmd_2.UseVisualStyleBackColor = True
        '
        'Cmd_1
        '
        Me.Cmd_1.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmd_1.Location = New System.Drawing.Point(12, 264)
        Me.Cmd_1.Name = "Cmd_1"
        Me.Cmd_1.Size = New System.Drawing.Size(54, 50)
        Me.Cmd_1.TabIndex = 45
        Me.Cmd_1.Text = "1"
        Me.Cmd_1.UseVisualStyleBackColor = True
        '
        'Calculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(349, 492)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Cmd_Decimal)
        Me.Controls.Add(Me.Cmd_0)
        Me.Controls.Add(Me.Lbl3)
        Me.Controls.Add(Me.Lbl2)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.Cmd_menu)
        Me.Controls.Add(Me.Cmd_Reset)
        Me.Controls.Add(Me.Cmd_Backspace)
        Me.Controls.Add(Me.Cmd_Divide)
        Me.Controls.Add(Me.TxtBxCalc)
        Me.Controls.Add(Me.Cmd_Subtract)
        Me.Controls.Add(Me.Cmd_Add)
        Me.Controls.Add(Me.Cmd_Multiply)
        Me.Controls.Add(Me.Cmd_Equ)
        Me.Controls.Add(Me.Cmd_6)
        Me.Controls.Add(Me.Cmd_8)
        Me.Controls.Add(Me.Cmd_7)
        Me.Controls.Add(Me.Cmd_3)
        Me.Controls.Add(Me.Cmd_5)
        Me.Controls.Add(Me.Cmd_4)
        Me.Controls.Add(Me.Cmd_9)
        Me.Controls.Add(Me.Cmd_2)
        Me.Controls.Add(Me.Cmd_1)
        Me.Name = "Calculator"
        Me.Text = "Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Cmd_Decimal As Button
    Friend WithEvents Cmd_0 As Button
    Friend WithEvents Lbl3 As Label
    Friend WithEvents Lbl2 As Label
    Friend WithEvents lbl1 As Label
    Friend WithEvents Cmd_menu As Button
    Friend WithEvents Cmd_Reset As Button
    Friend WithEvents Cmd_Backspace As Button
    Friend WithEvents Cmd_Divide As Button
    Friend WithEvents TxtBxCalc As TextBox
    Friend WithEvents Cmd_Subtract As Button
    Friend WithEvents Cmd_Add As Button
    Friend WithEvents Cmd_Multiply As Button
    Friend WithEvents Cmd_Equ As Button
    Friend WithEvents Cmd_6 As Button
    Friend WithEvents Cmd_8 As Button
    Friend WithEvents Cmd_7 As Button
    Friend WithEvents Cmd_3 As Button
    Friend WithEvents Cmd_5 As Button
    Friend WithEvents Cmd_4 As Button
    Friend WithEvents Cmd_9 As Button
    Friend WithEvents Cmd_2 As Button
    Friend WithEvents Cmd_1 As Button
End Class
